import pandas as pd
import streamlit as st

from core.validators import diagnosticar_nomes_bloqueados_para_sorteio



def init_session_state(logic):
    if 'df_base' not in st.session_state:
        st.session_state.df_base = logic.criar_base_vazia()

    if 'novos_jogadores' not in st.session_state:
        st.session_state.novos_jogadores = []

    if 'is_admin' not in st.session_state:
        st.session_state.is_admin = False

    if 'aviso_sem_planilha' not in st.session_state:
        st.session_state.aviso_sem_planilha = False

    if 'diagnostico_lista' not in st.session_state:
        st.session_state.diagnostico_lista = None

    if 'lista_revisada' not in st.session_state:
        st.session_state.lista_revisada = None

    if 'lista_revisada_confirmada' not in st.session_state:
        st.session_state.lista_revisada_confirmada = False

    if 'lista_texto_revisado' not in st.session_state:
        st.session_state.lista_texto_revisado = ""

    if 'revisao_lista_expandida' not in st.session_state:
        st.session_state.revisao_lista_expandida = False

    if "faltantes_revisao" not in st.session_state:
        st.session_state.faltantes_revisao = []

    if "cadastro_guiado_ativo" not in st.session_state:
        st.session_state.cadastro_guiado_ativo = False

    if "faltantes_cadastrados_na_rodada" not in st.session_state:
        st.session_state.faltantes_cadastrados_na_rodada = []

    if "revisao_pendente_pos_cadastro" not in st.session_state:
        st.session_state.revisao_pendente_pos_cadastro = False



def atualizar_integridade_base_no_estado(logic):
    if hasattr(logic, "diagnosticar_inconsistencias_base"):
        st.session_state.base_inconsistencias_carregamento = logic.diagnosticar_inconsistencias_base(
            st.session_state.df_base
        )
    if hasattr(logic, "listar_registros_inconsistentes"):
        st.session_state.base_registros_inconsistentes_carregamento = (
            logic.listar_registros_inconsistentes(st.session_state.df_base).to_dict("records")
        )
    else:
        st.session_state.base_registros_inconsistentes_carregamento = []


def limpar_estado_revisao_lista():
    st.session_state.diagnostico_lista = None
    st.session_state.lista_revisada = None
    st.session_state.lista_revisada_confirmada = False
    st.session_state.lista_texto_revisado = ""
    st.session_state.revisao_lista_expandida = False


def diagnosticar_lista_no_estado(logic, lista_texto: str):
    processamento = logic.processar_lista(
        lista_texto,
        return_metadata=True,
        emit_warning=False,
    )

    if not processamento["jogadores"]:
        limpar_estado_revisao_lista()
        return None

    diagnostico = logic.diagnosticar_lista_para_sorteio(
        lista_texto,
        st.session_state.df_base,
        st.session_state.novos_jogadores,
    )

    df_final = st.session_state.df_base.copy()
    if st.session_state.novos_jogadores:
        df_final = pd.concat([df_final, pd.DataFrame(st.session_state.novos_jogadores)], ignore_index=True)

    nomes_bloqueados_base = diagnosticar_nomes_bloqueados_para_sorteio(
        df_final,
        diagnostico.get("lista_final_sugerida", []),
    )
    diagnostico["nomes_bloqueados_base"] = nomes_bloqueados_base
    diagnostico["tem_bloqueio_base"] = len(nomes_bloqueados_base) > 0

    st.session_state.diagnostico_lista = diagnostico
    st.session_state.lista_revisada = None
    st.session_state.lista_revisada_confirmada = False
    st.session_state.lista_texto_revisado = lista_texto
    st.session_state.revisao_lista_expandida = True
    return diagnostico
